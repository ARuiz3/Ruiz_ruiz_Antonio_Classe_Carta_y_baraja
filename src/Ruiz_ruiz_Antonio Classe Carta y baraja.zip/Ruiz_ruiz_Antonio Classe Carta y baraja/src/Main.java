import Classes.Baraja;

/**
 * @author Antonio Ruiz Ruiz
 * @version 12.12.2022
 * @since JDK 19.0
 */
public class Main {
    public static void main(String[] args) {
        //creacion de objetos
        Baraja b= new Baraja();
        //uso de metodos de la clase Classes.Baraja
        b.mostrarBaraja();
    }

}
