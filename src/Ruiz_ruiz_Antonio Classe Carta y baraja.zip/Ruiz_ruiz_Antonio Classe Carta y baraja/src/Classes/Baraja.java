package Classes;

/**
 * @author Antonio Ruiz Ruiz
 * @version 12.12.2022
 * @since JDK 19.0
 */
public class Baraja {

    //creación del objeto carta
    Carta c= new Carta();

    //constructor por defecto
    public Baraja(){
    }
    /*
    metodo donde se crea un objeto carta donde a través
    de un while con la condición i<NCARTASBARAJA donde i és un contador.
    Después se hacen un switch donde se usa i como expresión
    con 4 casos, cada uno con 12 números de rango(ya que
    cada palo contiene 12 cartas) dentro de cada case primeramente se cambia
    el coll del objeto carta y después se hace un bucle for donde se guarda
    en el array baraja[] las cartas del 1 al 12 del palo correspondiente y se
    va aumentando el contador.
     */
    public void mostrarBaraja(){
        //creación de variables
        String palo[]= {"oros","bastos","espases","copes"};
        int numero[]={1,2,3,4,5,6,7,8,9,10,11,12};
        for (int i=0; i<palo.length;i++){
            c.setColl(palo[i]);
            for(int j=0;j< numero.length;j++){
                c.setNumero(numero[j]);
                System.out.println(c);
            }
        }
    }
}
